<?php

$api_key = $api_key = get_option('aqg_api_key');
?>

<form method="post">

    <input
        type="text"
        name="prompt"
        placeholder="Enter prompt..."
    >

    <button type="submit">
        Generate Quote
    </button>

</form>

<?php

if (isset($_POST['prompt'])) {

    $prompt = $_POST['prompt'];

    if (empty($prompt)) {

        echo 'Please enter a prompt';

        return;
    }

    $result = generate_quote($prompt, $api_key);

    if ($result === false) {

        echo 'Failed To Generate Quote';

        return;
    }

    echo '<h2>Generated Quote</h2>';
    echo '<p>' . $result['quote'] . '</p>';
}