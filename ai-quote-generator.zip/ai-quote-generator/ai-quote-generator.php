<?php
/*
Plugin Name: API Quote Generator
Description: generates quote from OPEN AI. (Form shortcode: [ai_quote_generator])
Version: 1.0
Author: Don Geverola
*/


include __DIR__ . '/includes/ai-helper.php';
include __DIR__ . '/includes/settings-page.php';

function aqg_render_quote_viewer() {
    ob_start();

    include __DIR__ . '/templates/quote-viewer.php';

    return ob_get_clean();
}

add_shortcode('ai_quote_generator', 'aqg_render_quote_viewer');