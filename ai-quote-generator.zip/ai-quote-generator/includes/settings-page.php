<?php

function aqg_register_settings_page() {

    add_options_page(
        'AI Quote Generator',
        'AI Quote Generator',
        'manage_options',
        'aqg-settings',
        'aqg_settings_page'
    );
}

add_action('admin_menu', 'aqg_register_settings_page');

function aqg_register_settings() {

    register_setting(
        'aqg_settings_group',
        'aqg_api_key'
    );
}

add_action('admin_init', 'aqg_register_settings');

function aqg_settings_page() {
    ?>

    <div class="wrap">

        <h1>AI Quote Generator Settings</h1>

        <form method="post" action="options.php">

            <?php settings_fields('aqg_settings_group'); ?>

            <table class="form-table">

                <tr>
                    <th scope="row">
                        <label for="aqg_api_key">OpenAI API Key</label>
                    </th>

                    <td>
                        <input
                            type="password"
                            id="aqg_api_key"
                            name="aqg_api_key"
                            value="<?php echo esc_attr(get_option('aqg_api_key')); ?>"
                            class="regular-text"
                        >
                    </td>
                </tr>

            </table>

            <?php submit_button(); ?>

        </form>

    </div>

    <?php
}