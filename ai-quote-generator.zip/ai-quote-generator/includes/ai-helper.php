<?php

function generate_quote($prompt, $api_key) {

    if (empty($prompt)) {
        return false;
    }

    $response = wp_remote_post(
        'https://api.openai.com/v1/chat/completions',
        [
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json'
            ],
            'body' => json_encode([
                'model' => 'gpt-4.1-mini',
                'messages' => [
                    [
                        'role' => 'user',
                        'content' => $prompt
                    ]
                ]
            ])
        ]
    );

    $status_code = wp_remote_retrieve_response_code($response);

    if ($status_code !== 200) {
        return false;
    }

    $body = wp_remote_retrieve_body($response);

    $data = json_decode($body, true);

    $quote = $data['choices'][0]['message']['content'];

    return [
        'status_code' => $status_code,
        'quote' => $quote
    ];
}