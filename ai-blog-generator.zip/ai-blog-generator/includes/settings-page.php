<?php

function abg_register_settings_page() {

    add_options_page(
        'AI Blog Generator',
        'AI Blog Generator',
        'manage_options',
        'abg-settings',
        'abg_settings_page'
    );
}

add_action('admin_menu', 'abg_register_settings_page');

function abg_register_settings() {

    register_setting(
        'abg_settings_group',
        'abg_api_key'
    );
}

add_action('admin_init', 'abg_register_settings');

function abg_settings_page() {
    ?>

    <div class="wrap">

        <h1>AI Blog Generator Settings</h1>

        <form method="post" action="options.php">

            <?php settings_fields('abg_settings_group'); ?>

            <table class="form-table">

                <tr>
                    <th scope="row">
                        <label for="abg_api_key">OpenAI API Key</label>
                    </th>

                    <td>
                        <input
                            type="password"
                            id="abg_api_key"
                            name="abg_api_key"
                            value="<?php echo esc_attr(get_option('abg_api_key')); ?>"
                            class="regular-text"
                        >
                    </td>
                </tr>


            </table>

            <?php submit_button(); ?>

        </form>

    </div>

    <?php
}