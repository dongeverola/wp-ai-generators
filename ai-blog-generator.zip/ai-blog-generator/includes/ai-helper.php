<?php

function generate_blog($topic, $instructions, $word_count, $api_key) {

    if (empty($topic)) {
        return false;
    }

$prompt =
'Write a blog post with approximately ' . $word_count . ' words.

Topic:
' . $topic . '

Additional Instructions:
' . $instructions . '

Requirements:
- Write an engaging introduction
- Use HTML tags instead of Markdown
- Use <h2> tags for main headings
- Use <h3> tags for FAQ questions
- Use <p> tags for paragraphs
- Include a FAQ section
- Write a conclusion
- Make it SEO friendly
- Write in a professional tone

Important:
Return only the blog HTML content.
Do not wrap the response in markdown code blocks.';

    $response = wp_remote_post(
        'https://api.openai.com/v1/chat/completions',
        [
            'timeout' => 30,
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json'
            ],
            'body' => json_encode([
                'model' => 'gpt-4.1-mini',
                'messages' => [
                    [
                        'role' => 'user',
                        'content' => $prompt
                    ]
                ]
            ])
        ]
    );

    if (is_wp_error($response)) {

    echo '<pre>';
    print_r($response->get_error_message());
    echo '</pre>';

    return false;
}

    $status_code = wp_remote_retrieve_response_code($response);

    if ($status_code !== 200) {
        return false;
    }

    $body = wp_remote_retrieve_body($response);

    $data = json_decode($body, true);

    if (!isset($data['choices'][0]['message']['content'])) {
        return false;
    }

    $blog = $data['choices'][0]['message']['content'];

    return [
        'status_code' => $status_code,
        'blog' => $blog
    ];
}

function save_blog_draft($title, $content) {

    if (empty($title) || empty($content)) {
        return false;
    }

    $post_id = wp_insert_post([
        'post_title'   => sanitize_text_field($title),
        'post_content' => wp_kses_post($content),
        'post_status'  => 'draft',
        'post_type'    => 'post'
    ]);

    if (is_wp_error($post_id)) {
        return false;
    }

    return $post_id;
}