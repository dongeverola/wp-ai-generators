<?php
/*
Plugin Name: AI Blog Generator
Description: Generates blog posts using OpenAI API. shortcode: [ai_blog_generator]
Version: 1.0
Author: Don Geverola
*/

include __DIR__ . '/includes/ai-helper.php';
include __DIR__ . '/includes/settings-page.php';

function abg_render_blog_viewer() {
    ob_start();

    include __DIR__ . '/templates/blog-viewer.php';

    return ob_get_clean();
}

add_shortcode('ai_blog_generator', 'abg_render_blog_viewer');