<?php

$api_key = get_option('abg_api_key');

if (isset($_POST['draft_content'])) {

    $draft_title = $_POST['draft_title'];
    $draft_content = $_POST['draft_content'];

    $post_id = save_blog_draft(
        $draft_title,
        $draft_content
    );

    if ($post_id === false) {

        echo 'Failed to save draft';

    } else {

        $preview_url = get_preview_post_link($post_id);
        $edit_url = get_edit_post_link($post_id);

        echo '<div class="notice notice-success">';
        echo '<p>✅ Draft saved successfully.</p>';
        echo '<p>';
        echo '<a href="' . esc_url($preview_url) . '" target="_blank">Preview Draft</a>';
        echo ' | ';
        echo '<a href="' . esc_url($edit_url) . '" target="_blank">Edit Draft</a>';
        echo ' | ';
        echo '<a href="' . esc_url(get_permalink()) . '">Generate New Blog</a>';
        echo '</p>';
        echo '</div>';
    }

    return;
}

?>

<form method="post">

    <input
        type="text"
        name="topic"
        placeholder="Enter blog topic..."
    >

    <br><br>

    <textarea
        name="instructions"
        placeholder="Additional instructions..."
        rows="6"
        cols="60"
    ></textarea>

    <br><br>

    <select name="word_count">
        <option value="100">100 words</option>
        <option value="200">200 words</option>
        <option value="300">300 words</option>
        <option value="400">400 words</option>
    </select>

    <br><br>

    <button type="submit">
        Generate Blog
    </button>

</form>

<?php

if (isset($_POST['topic']) && !isset($_POST['draft_content'])) {

    $topic = $_POST['topic'];
    $instructions = $_POST['instructions'];
    $word_count = $_POST['word_count'];

    if (empty($topic)) {
        echo 'Please enter a blog topic';
        return;
    }

    $result = generate_blog(
        $topic,
        $instructions,
        $word_count,
        $api_key
    );

    if ($result === false) {
        echo 'Failed To Generate Blog';
        return;
    }

    echo '<h2>Generated Blog</h2>';

    echo wp_kses_post($result['blog']);

    ?>

    <form method="post">

        <input
            type="hidden"
            name="draft_title"
            value="<?php echo esc_attr($topic); ?>"
        >

        <textarea
            name="draft_content"
            style="display:none;"
        ><?php echo esc_textarea($result['blog']); ?></textarea>

        <button type="submit">
            Save Draft
        </button>

    </form>

    <?php
}
?>