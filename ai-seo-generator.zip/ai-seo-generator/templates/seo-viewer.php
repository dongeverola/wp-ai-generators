<?php

$api_key = get_option('asg_api_key');

?>

<form method="post">

    <input
        type="text"
        name="topic"
        placeholder="Enter topic..."
    >

    <br><br>

    <button type="submit">
        Generate SEO
    </button>

</form>

<?php

if (isset($_POST['topic'])) {

    $topic = $_POST['topic'];

    if (empty($topic)) {
        echo 'Please enter a topic';
        return;
    }

    $result = generate_seo(
        $topic,
        $api_key
    );

    if ($result === false) {
        echo 'Failed To Generate SEO';
        return;
    }

    $seo_data = $result['seo_data'];

    echo '<h2>Generated SEO</h2>';

    echo '<h3>SEO Title</h3>';
    echo '<p>' . esc_html($seo_data['seo_title']) . '</p>';

    echo '<h3>Meta Description</h3>';
    echo '<p>' . esc_html($seo_data['meta_description']) . '</p>';

    echo '<h3>Keywords</h3>';

    echo '<ul>';

    foreach ($seo_data['keywords'] as $keyword) {
        echo '<li>' . esc_html($keyword) . '</li>';
    }

    echo '</ul>';
}