<?php
/*
Plugin Name: AI SEO Generator
Description: Generates SEO title, meta description, and keywords using OpenAI API. Shortcode: [ai_seo_generator]
Version: 1.0
Author: Don Geverola
*/

include __DIR__ . '/includes/ai-helper.php';
include __DIR__ . '/includes/settings-page.php';

function asg_render_seo_viewer() {
    ob_start();

    include __DIR__ . '/templates/seo-viewer.php';

    return ob_get_clean();
}

add_shortcode('ai_seo_generator', 'asg_render_seo_viewer');