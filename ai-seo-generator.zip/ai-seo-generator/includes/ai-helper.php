<?php
function generate_seo($topic, $api_key) {

    if (empty($topic) || empty($api_key)) {
        return false;
    }

    $prompt = '

You are an expert SEO specialist.

Generate SEO information for the following topic.

Topic:
' . $topic . '

Return:
- SEO Title
- Meta Description
- Keywords

Return valid JSON only with the following structure:

{
    "seo_title": "",
    "meta_description": "",
    "keywords": []
}

';

    $body = [
        'model' => 'gpt-4.1-mini',

        'response_format' => [
            'type' => 'json_schema',
            'json_schema' => [
                'name' => 'seo_response',
                'strict' => true,
                'schema' => [
                    'type' => 'object',
                    'properties' => [
                        'seo_title' => [
                            'type' => 'string'
                        ],
                        'meta_description' => [
                            'type' => 'string'
                        ],
                        'keywords' => [
                            'type' => 'array',
                            'items' => [
                                'type' => 'string'
                            ]
                        ]
                    ],
                    'required' => [
                        'seo_title',
                        'meta_description',
                        'keywords'
                    ],
                    'additionalProperties' => false
                ]
            ]
        ],

        'messages' => [
            [
                'role' => 'user',
                'content' => $prompt
            ]
        ]
    ];

    $response = wp_remote_post(
        'https://api.openai.com/v1/chat/completions',
        [
            'timeout' => 30,

            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json'
            ],

            'body' => json_encode($body)
        ]
    );

    if (is_wp_error($response)) {
        return false;
    }

    $status_code = wp_remote_retrieve_response_code($response);

    if ($status_code !== 200) {
        return false;
    }

    $response_body = wp_remote_retrieve_body($response);

    $data = json_decode($response_body, true);

    if (!isset($data['choices'][0]['message']['content'])) {
        return false;
    }

    $seo_data = json_decode(
        $data['choices'][0]['message']['content'],
        true
    );

    if (
        !isset($seo_data['seo_title']) ||
        !isset($seo_data['meta_description']) ||
        !isset($seo_data['keywords'])
    ) {
        return false;
    }

    return [
        'status_code' => $status_code,
        'seo_data' => $seo_data
    ];
}