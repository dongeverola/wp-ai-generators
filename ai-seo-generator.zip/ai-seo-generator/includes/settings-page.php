<?php

function asg_register_settings_page() {

    add_options_page(
        'AI SEO Generator',
        'AI SEO Generator',
        'manage_options',
        'asg-settings',
        'asg_settings_page'
    );
}

add_action('admin_menu', 'asg_register_settings_page');

function asg_register_settings() {

    register_setting(
        'asg_settings_group',
        'asg_api_key'
    );
}

add_action('admin_init', 'asg_register_settings');

function asg_settings_page() {
    ?>

    <div class="wrap">

        <h1>AI SEO Generator Settings</h1>

        <form method="post" action="options.php">

            <?php settings_fields('asg_settings_group'); ?>

            <table class="form-table">

                <tr>
                    <th scope="row">
                        <label for="asg_api_key">OpenAI API Key</label>
                    </th>

                    <td>
                        <input
                            type="password"
                            id="asg_api_key"
                            name="asg_api_key"
                            value="<?php echo esc_attr(get_option('asg_api_key')); ?>"
                            class="regular-text"
                        >
                    </td>
                </tr>

            </table>

            <?php submit_button(); ?>

        </form>

    </div>

    <?php
}